#pragma once

#define HTTP_SERVER "Urip"
#define HTTP_PORT 80

#define TFTP_SERVER "Urip"
