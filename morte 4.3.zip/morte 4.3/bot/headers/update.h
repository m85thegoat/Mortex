#ifndef MORTE_UPDATE_H
#define MORTE_UPDATE_H

void handle_update(char *buf, int len);

#endif
